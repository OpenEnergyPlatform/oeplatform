
Contact and links
=================

A forum/mailing list is available for Owlready on Nabble: http://owlready.306.s1.nabble.com

In case of trouble, please write to the forum or contact Jean-Baptiste Lamy <jean-baptiste.lamy *@* univ-paris13 *.* fr>

::

  LIMICS
  University Paris 13, Sorbonne Paris Cité
  Bureau 149
  74 rue Marcel Cachin
  93017 BOBIGNY
  FRANCE

Owlready on BitBucket (Git development repository): https://bitbucket.org/jibalamy/owlready2
